package org.oceanoxygen.tnr.util;

public interface CoreChangeListener {

	public void onCoreChange();
}
